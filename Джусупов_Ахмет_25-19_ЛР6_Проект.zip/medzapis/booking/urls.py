from django.urls import path

from . import views

urlpatterns = [
    path("", views.doctor_screen, name="doctor-screen"),
    path("api/doctors/", views.doctors_api, name="doctors-api"),
]
