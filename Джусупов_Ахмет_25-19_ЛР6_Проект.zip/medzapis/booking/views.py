from django.http import JsonResponse
from django.shortcuts import render

from .services import QueryError, list_available_doctors


def doctor_screen(request):
    specialty, query = request.GET.get("specialty", "Терапия"), request.GET.get("q", "")
    try:
        items = list_available_doctors(specialty, query)
        error, status = "", 200
    except QueryError as exc:
        items, error, status = [], str(exc), 400
    return render(
        request,
        "booking/doctors.html",
        {"doctors": items, "error": error, "query": query, "specialty": specialty},
        status=status,
    )


def doctors_api(request):
    try:
        items = list_available_doctors(
            request.GET.get("specialty", "Терапия"), request.GET.get("q", "")
        )
    except QueryError as exc:
        return JsonResponse({"error": "INVALID_SEARCH", "message": str(exc)}, status=400)
    return JsonResponse({"items": items}, json_dumps_params={"ensure_ascii": False})
