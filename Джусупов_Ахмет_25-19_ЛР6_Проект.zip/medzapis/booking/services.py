"""Логика выбора: БП-01 из приложенной ЛР №5 Джусупова Ахмета."""

from datetime import datetime

from schedule import services as schedule
from schedule.repositories import TZ

from . import repositories


class QueryError(ValueError):
    pass


def list_available_doctors(specialty="", query="", now=None):
    query = query.strip()
    if query and not 2 <= len(query) <= 150:
        raise QueryError("Введите от 2 до 150 символов для поиска врача")
    now = now or datetime.now(TZ)
    occupied = repositories.occupied_time_ids()
    times = schedule.list_times()
    result = []
    for doctor in schedule.list_doctors():
        if not doctor["active"] or (specialty and doctor["specialty"] != specialty):
            continue
        if query and query.casefold() not in doctor["name"].casefold():
            continue
        free = [
            t
            for t in times
            if t["doctor_id"] == doctor["id"] and t["id"] not in occupied and t["start"] > now
        ]
        if free:
            first = min(free, key=lambda t: t["start"])
            result.append(
                {**doctor, "free_count": len(free), "next_start": first["start"].isoformat()}
            )
    return result
