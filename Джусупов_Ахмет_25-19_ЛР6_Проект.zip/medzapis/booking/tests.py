from datetime import datetime, timedelta
from unittest.mock import patch

from django.test import SimpleTestCase

from booking.services import QueryError, list_available_doctors
from schedule.repositories import TZ

NOW = datetime(2026, 11, 2, 9, tzinfo=TZ)


class AvailabilityTests(SimpleTestCase):
    def test_inactive_doctor_excluded(self):
        self.assertNotIn("d3", [d["id"] for d in list_available_doctors(now=NOW)])

    def test_occupied_time_excluded(self):
        result = list_available_doctors(query="Иванова", now=NOW)
        self.assertEqual(result[0]["free_count"], 1)
        self.assertIn("10:20", result[0]["next_start"])

    def test_no_free_times_excluded(self):
        with patch("booking.repositories.occupied_time_ids", return_value={"t1", "t2"}):
            self.assertEqual(list_available_doctors(query="Иванова", now=NOW), [])

    def test_short_search_rejected(self):
        with self.assertRaises(QueryError):
            list_available_doctors(query="И", now=NOW)

    def test_case_insensitive_search(self):
        self.assertEqual(list_available_doctors(query="иВаНоВа", now=NOW)[0]["id"], "d1")

    def test_specialty_filter(self):
        self.assertEqual(list_available_doctors("Кардиология", now=NOW)[0]["id"], "d4")

    def test_past_times_excluded(self):
        with patch(
            "schedule.repositories.list_times",
            return_value=[{"id": "past", "doctor_id": "d1", "start": NOW - timedelta(minutes=1)}],
        ):
            self.assertEqual(list_available_doctors(now=NOW), [])


class HttpTests(SimpleTestCase):
    def test_screen_matches_api(self):
        screen, api = self.client.get("/"), self.client.get("/api/doctors/")
        self.assertEqual(api.status_code, 200)
        for doctor in api.json()["items"]:
            self.assertContains(screen, doctor["name"])
        self.assertEqual(len(api.json()["items"]), 2)

    def test_invalid_search(self):
        response = self.client.get("/api/doctors/?q=И")
        self.assertEqual(response.status_code, 400)

    def test_search_on_screen(self):
        response = self.client.get("/?q=Иванова")
        self.assertContains(response, "Иванова Анна Сергеевна")
        self.assertNotContains(response, "Омаров Данияр Ерланович")
