"""Сервисы справочника: предоставляют врача и его рабочее расписание."""

from . import repositories


def list_doctors():
    return repositories.list_doctors()


def list_times():
    return repositories.list_times()
