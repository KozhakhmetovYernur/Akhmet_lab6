"""Данные врача и его расписания: учебная заглушка, не МИС."""

from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Almaty")


def list_doctors():
    return [
        {
            "id": "d1",
            "name": "Иванова Анна Сергеевна",
            "specialty": "Терапия",
            "cabinet": "204",
            "active": True,
        },
        {
            "id": "d2",
            "name": "Омаров Данияр Ерланович",
            "specialty": "Терапия",
            "cabinet": "208",
            "active": True,
        },
        {
            "id": "d3",
            "name": "Петров Алексей Викторович",
            "specialty": "Терапия",
            "cabinet": "210",
            "active": False,
        },
        {
            "id": "d4",
            "name": "Садыкова Айгерим Маратовна",
            "specialty": "Кардиология",
            "cabinet": "302",
            "active": True,
        },
    ]


def list_times():
    tomorrow = datetime.now(TZ).date() + timedelta(days=1)
    start = datetime.combine(tomorrow, time(10), TZ)
    return [
        {"id": "t1", "doctor_id": "d1", "start": start},
        {"id": "t2", "doctor_id": "d1", "start": start + timedelta(minutes=20)},
        {"id": "t3", "doctor_id": "d2", "start": start},
        {"id": "t4", "doctor_id": "d3", "start": start},
        {"id": "t5", "doctor_id": "d4", "start": start + timedelta(hours=1)},
    ]
