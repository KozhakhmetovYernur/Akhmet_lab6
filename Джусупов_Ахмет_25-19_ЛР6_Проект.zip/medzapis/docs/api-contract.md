# МедЗапись: проектный контракт
Источник: приложенная ЛР №5 Джусупова Ахмета. Полная ЛР №4 не предоставлена.
Уточнение: Э-04 выбирает время; Э-05 подтверждает и создаёт; Э-06 показывает результат.
БП-01: активный врач, свободное время. БП-02: повторная проверка.
БП-03: сохранение после подтверждения. БП-04: отправка подтверждения <=60 секунд.

Проектные операции:
GET /api/specialties/ -> 200 items.
GET /api/doctors/?specialty=...&q=... -> 200 items.
GET /api/doctors/{id}/schedule/?date=... -> 200 working_dates/free_times;
503 ошибка загрузки, 200 free_times=[] при пустом расписании.
POST /api/booking-previews/ {doctor_id,time_id} -> 200 summary, без резерва.
POST /api/bookings/ {doctor_id,time_id,confirmed:true} + Idempotency-Key
-> 201 id/state/notification; исключение 6а: 409 SLOT_BUSY.
confirmed=false -> 400 CONFIRMATION_REQUIRED.
GET /api/bookings/{id}/ -> 200 result/notification.
GET /api/booking-requests/{key}/ -> 200 booking_id либо 404.
После сетевого тайм-аута сначала проверяется результат по прежнему ключу.

В текущем скелете реализованы только HTML / и GET /api/doctors/.
Фильтры specialty (по умолчанию Терапия), q (пустой либо 2–150 символов).
400 INVALID_SEARCH при неверной длине; 200 items=[] при пустом результате.
Проверка активности и незанятых будущих интервалов выполняется booking.services.
Заглушки вместо БД. МИС, транзакции сохранения и доставка подтверждений не реализованы.
